// AppContainer now re-exports the single app entry at `src/App.jsx`.
// This keeps compatibility while ensuring `src/App.jsx` is the primary app file.
import App from './App.jsx';

export default App;
